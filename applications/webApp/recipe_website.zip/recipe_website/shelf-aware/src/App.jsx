import AIRecommend from '../components/AI-Card/AIRecommend'
import Header from '../components/Header'
import Ingredients from '../components/Ingredients-Card/Ingredients'
import Recipes from '../components/Recipes-Card/Recipes'
import './App.css'

function App() {
  return (
    <>
    <Header />
    <div className="content-container">
      <Ingredients />
      <Recipes />
      <AIRecommend />
    </div>
    </>
  )
}

export default App
