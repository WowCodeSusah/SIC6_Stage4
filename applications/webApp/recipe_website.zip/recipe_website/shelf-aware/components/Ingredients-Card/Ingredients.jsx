import '../../styles/Ingredients.css'

function Ingredients(){

    const ingredientsList = [
        {
            Ingredients: [
                "1 beef",
                "5 onion",
                "5 carrot",
                "1 apple",
            ],
        },
    ];

    const selectedIngredients = ingredientsList[0]; // Change to [1] or random if needed

    return(
        <div className='ingredients-card'>
            <h2>Ingredients You Have</h2>
            <ul>
                {selectedIngredients.Ingredients.map((item, i) => (
                    <li key={i}>{item}</li>
                ))}
            </ul>
        </div>
    )
}

export default Ingredients