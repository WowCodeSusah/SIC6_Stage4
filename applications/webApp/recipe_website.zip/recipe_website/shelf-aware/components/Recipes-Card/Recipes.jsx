import { useState } from 'react'
import '../../styles/Recipes.css'

function Recipes(){

    const recipeList = [
        {
          Title: "Perfect Pot Roast",
          Ingredients: [
            "sea salt and freshly ground black pepper",
            "1/2 teaspoon ground fennel",
            "1 (3-pound) chuck roast",
            "extra virgin olive oil",
            "3 large carrots, peeled and cut into 2-inch-long chunks",
            "1/2 pound cipollini onions, peeled, or 1 large vidalia onion, cut into 1/4- to 1/2-inch dice",
            "3 garlic cloves, smashed",
            "1 1/4 cups hard cider (or apple cider if you prefer nonalcoholic)",
            "3 1/2 cups beef broth",
            "6 fresh thyme sprigs",
            "1 fresh rosemary sprig",
            "1 fresh or dried bay leaf",
            "2 tablespoons all-purpose flour",
            "2 tablespoons tomato paste"
          ],
          Instructions: [
            "Preheat the oven to 325ºF.",
            "Combine the salt, pepper, and ground fennel in a small bowl. Generously season the roast with the spice mixture.",
            "Add oil to a Dutch oven, heat over medium-high, sear roast 8–10 minutes turning to brown all sides, transfer to bowl.",
            "Add carrots, onions, garlic; season with salt and pepper. Sauté until browned, 5–8 minutes. Remove to bowl.",
            "Deglaze pot with 1 cup cider, scraping up brown bits. Boil. Add 2 cups broth, bring to boil again.",
            "Add 4 thyme sprigs, rosemary, bay leaf, roast. Bring to boil, reduce to simmer.",
            "Cover and roast in oven for 2 hours. Add reserved vegetables and roast 1 hour more.",
            "Remove roast/vegetables, strain and purée braising liquid, skim fat.",
            "In Dutch oven, heat oil, stir in flour. Add 1/4 cup cider and tomato paste. Stir.",
            "Return braising liquid and remaining broth. Add 2 thyme sprigs. Boil, then simmer 15–20 minutes to thicken.",
            "Season sauce. Remove thyme. Serve roast with vegetables and sauce poured over."
          ]
        },
        {
          Title: "Rintaro's Beef Curry",
          Ingredients: [
            "2 japanese or persian cucumbers",
            "kosher salt",
            "1 garlic clove",
            "1/2 cup plain whole-milk yogurt",
            "1/2 cup plain whole-milk greek yogurt",
            "1 tablespoon all-purpose flour",
            "1 tablespoon potato starch or cornstarch",
            "3 tablespoons vegetable oil",
            "2 pound beef chuck, cut into 1/2–1\" pieces",
            "3 medium onions, chopped",
            "1 apple, peeled, grated",
            "3 tablespoons mirin",
            "1 tablespoon finely chopped peeled ginger",
            "2 garlic cloves, finely chopped",
            "3 tablespoons curry powder",
            "2 tablespoons kuro sato or substitute with 1 tbsp sugar + 1/2 tsp molasses",
            "1 tablespoon garam masala",
            "1 tablespoon soy sauce",
            "4 cups low-sodium chicken broth",
            "1/2 kabocha squash, peeled, seeded, cut into 1/2\" pieces",
            "1 large yukon gold potato, scrubbed, cut into 1/2\" pieces",
            "2 large carrots, peeled, cut into 1/2\" pieces",
            "steamed white rice"
          ],
          Instructions: [
            "Slice cucumbers, salt, rest 5 minutes. Rinse, squeeze, and mix with garlic paste and yogurt. Season.",
            "Mix flour, starch, and water to make slurry. Set aside.",
            "Heat oil, season beef, sear in batches until browned. Remove.",
            "Add onions and apple; cook until onions are soft. Add mirin, ginger, garlic. Cook until fragrant.",
            "Add curry powder, sugar/molasses, garam masala, soy sauce, and broth. Simmer 30–40 minutes.",
            "Add squash, potato, carrots. Cover and simmer until tender, 20–30 minutes.",
            "Whisk slurry into curry using a sieve. Simmer until thickened, 8–10 minutes.",
            "Serve over rice topped with raita."
          ]
        },
        {
          Title: "Slow Cooker Bone Broth",
          Ingredients: [
            "10–12 pounds beef bones",
            "2 tablespoons apple cider vinegar",
            "2 onions, peeled and quartered",
            "2 carrots, peeled and cut in half",
            "2 celery stalks, cut in half",
            "2 bay leaves",
            "2 tablespoons peppercorns",
            "4 stems parsley",
            "1 teaspoon salt"
          ],
          Instructions: [
            "Place beef bones in slow cooker. Add remaining ingredients.",
            "Fill with water to cover contents.",
            "Cover and cook on high for 24–72 hours.",
            "Strain liquid, refrigerate, remove fat. Use as desired."
          ]
        },
        {
          Title: "Braised Short Ribs with Potatoes and Apples \"Risotto Style\"",
          Ingredients: [
            "6 (10-ounce) bone-in beef short ribs",
            "1 teaspoon fine sea salt",
            "1/2 cup olive oil",
            "3 medium onions, large dice",
            "1 head garlic, cloves whole",
            "3 medium carrots, large dice",
            "3 celery stalks, large dice",
            "2 granny smith apples, large dice",
            "2 cups dry red wine",
            "8 ounces strained tomato purée",
            "10 cups chicken stock or broth",
            "1/4 teaspoon black pepper",
            "4 bay leaves",
            "2 large yukon gold potatoes, small dice",
            "2 large granny smith apples, small dice",
            "2 tablespoons unsalted butter",
            "1 medium onion, small dice",
            "4 cloves garlic, minced",
            "1/2 cup dry white wine",
            "1/2 cup chicken stock or broth",
            "2 ounces parmesan cheese, grated",
            "juice of 1/2 lemon",
            "1/2 teaspoon sea salt",
            "1/4 teaspoon black pepper"
          ],
          Instructions: [
            "Salt ribs, refrigerate 24 hours.",
            "Preheat oven to 325°F. Sear ribs in batches, set aside.",
            "Add vegetables and apples, sauté until soft. Add wine, boil and scrape pan.",
            "Add tomato purée, stock, ribs, and herbs. Braise covered 2 hours.",
            "Uncover and braise 45 minutes more. Remove ribs, strain and reduce liquid.",
            "Reheat ribs in reduced liquid.",
            "Boil potatoes and apples 3 minutes. Drain and cool.",
            "Sauté onion and garlic in butter. Add wine, reduce.",
            "Add potatoes, apples, stock; simmer until creamy.",
            "Stir in cheese, butter, lemon, season. Serve ribs with risotto mixture."
          ]
        },
        {
          Title: "Braised Beef Short Ribs",
          Ingredients: [
            "4 (8-ounce) bone-in beef short ribs",
            "1 tablespoon vegetable oil",
            "3/4 teaspoon sea salt",
            "1/2 teaspoon black pepper",
            "4 medium carrots, finely chopped",
            "1 medium onion, finely chopped",
            "2 garlic cloves, finely chopped",
            "1 (14-ounce) can san marzano tomatoes, puréed",
            "1 1/2 cups dry red wine",
            "4 cups brown veal stock or diluted demi-glace",
            "2 sprigs fresh thyme",
            "1 bay leaf",
            "1 tablespoon banyuls or red-wine vinegar",
            "1 tablespoon balsamic vinegar",
            "20 pearl onions",
            "1 1/2 tablespoons unsalted butter",
            "2 cups chicken stock or broth",
            "4 medium carrots, diagonally cut",
            "3 thick bacon slices, chopped",
            "8 white mushrooms, quartered"
          ],
          Instructions: [
            "Preheat oven to 250°F. Brown beef, season with salt and pepper, set aside.",
            "Sauté chopped vegetables. Add tomatoes and wine; reduce.",
            "Add stock, herbs, vinegars, beef. Cover and braise 4–5 hours.",
            "Blanch and peel pearl onions.",
            "Cook onions in butter until browned. Add vinegar and stock with carrots, simmer until tender.",
            "Cook bacon and mushrooms until crisp and tender. Add to vegetables.",
            "Strain and reduce sauce. Serve ribs with vegetable mixture and sauce."
          ]
        },
        {
          Title: "Sour Cream Meat Loaf",
          Ingredients: [
            "2 lb. ground lean beef",
            "1 1/2 cups grated raw carrot",
            "1/4 cup grated unpeeled apple",
            "1 1/2 cups grated raw potato",
            "1 onion, quartered and studded with 4 cloves",
            "6 slices fried bacon, crumbled",
            "2 beaten eggs",
            "2 1/4 teaspoons salt",
            "1/2 teaspoon pepper",
            "1/8 teaspoon nutmeg",
            "1/8 teaspoon dry mustard",
            "2 cups sour cream"
          ],
          Instructions: [
            "Combine all ingredients in a large bowl. Mix well.",
            "Pack into a 9x5x3-inch loaf pan.",
            "Bake at 350°F for 1 1/2 to 1 3/4 hours.",
            "Serves 6."
          ]
        }
      ];
      
    const [currentIndex, setCurrentIndex] = useState(0);

    function randomizeRecipes() {
        const random = Math.floor(Math.random() * recipeList.length);
        setCurrentIndex(random);
    }
    
    const currentRecipe = recipeList[currentIndex];    

    return(
        <div className='recipes-card'>
            <h2>Possible Recipes to Make</h2>
            <div className="random-btn">
                <button onClick={randomizeRecipes}>Randomize Recipes</button>
            </div>
            <h3>Recipe Name</h3>
            <p>{currentRecipe.Title}</p>
            <h3>Ingredients Needed</h3>
            <ul>
                {currentRecipe.Ingredients.map((item, i) => (
                    <li key={i}>{item}</li>
                ))}
            </ul>
            <h3>Instructions (Step by Step)</h3>
            <ol>
                {currentRecipe.Instructions.map((step, i) => (
                    <li key={i}>{step}</li>
                ))}
            </ol>
        </div>
    )
}

export default Recipes