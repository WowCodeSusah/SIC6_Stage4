import '../styles/Header.css'

function Header(){
    return(
        <div className="container">
            <div className="container-header">
                {/* <img src="/logo.jpg"></img> */}
                <h1>Shelf-Aware</h1>
                <p>Don’t let your ingredients go to waste. Find easy, delicious recipes using what you already have. We’re here to make cooking simpler and smarter.</p>
            </div>
        </div>
    )
}

export default Header